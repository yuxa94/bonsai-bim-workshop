# 65B 단위세대

같은 폴더의 `65B.ifc`가 BIM 기준 파일입니다. IFC를 Bonsai에서 열어 학습하고, 수정 시 새 파일로 저장하세요.

`65B.blend`는 이 IFC를 Blender 4.4.0 / Bonsai 0.9.0-post1-py311로 가져와 저장한 표시 스냅샷입니다. IFC 편집의 기준·교환 파일로 대체하지 않습니다. IFC와 BLEND를 같은 폴더에 두세요. BLEND의 IFC 연결은 상대 경로입니다. Bonsai가 BLEND의 IFC 갱신 경고를 표시하면 같은 폴더의 IFC를 직접 다시 열어 확인하세요.

- 저장 원본 버전: 65B-v001
- IFC 제품 수: 143 (표시 대상 형상 125, 개구부 절삭용 피처 15)
- 공개 IFC SHA256: `0ee6fba3333995a9611b40d3455debb2eaf455c0086f512803e390415e0a22d3`
- 원본 IFC SHA256: `12215f8bd48275dcaef5a1fc97b893b6440c8b7bcd21b4667b921077fb56e05b`
- 동일성: 공개 복사본의 로컬 절대 경로 출처 문자열만 상대 경로로 바꿈. GUID·형상·배치 STEP 레코드는 동일.
- 미리보기: IFC에서 생성한 검토 이미지. 실제 가져온 메시의 평면·입체 투영이며, 화면 캡처나 원본 CAD가 아닙니다.
- 한계: Review assumptions apply. Window profiles and some fixtures are approximate.

IFC 스키마/형상 검토 모델이며 시공·허가·법규 적합 완료를 뜻하지 않습니다.
